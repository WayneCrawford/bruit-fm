The included files clean data using the tiskitpy software.
To run it, you will need the obspy software (installation instructions at)
and the tiskitpy code (installation instructions at )

The tiskitpy codes download an earthquake catalog from USGS, so for the first
run you need to be online.  They save the catalog locally, so you can work
offline afterwards

You'll need at least python 3.8 to run these codes

If you put this directory at the same level as the "REAL" directory it should
work as is, otherwise you will need to change the paths.

Files:

- ``clean_with_tiskitpy.py``: clean data with the automatic tiskit functions that:
    - avoid global earthquakes
    - rotating the Z-channel to minimize noise
    - remove coherent noise 
  Outputs:
    - "seismologist"-cleaned data:
    - "compliancist"-cleaned data:
    - estimated compliance:

- ``clean_with_tiskitpy_avoid.py``: Same process as above, plus cut out segments of
  bad/noisy data identified by eye.  Outputs:

    - "seismologist"-cleaned data:
    - "compliancist"-cleaned data:
    - estimated compliance:

- output_compliance.py: Used by the above codes to output a file of compliance
  in the challenge-specified format
  
- plot_compliance.py: Plots the compliance output file.
