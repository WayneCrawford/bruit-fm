"""
Calculate compliance automatically using tiskitpy using two cleaning steps
- Rotation of vertical channel to mimimize noise
- Transfer-function based noise removal (channel 1, then 2, then H)

All of the tiskitpy routines avoid global earthquakes (from USGS catalog)
"""
from obspy import read, read_inventory, UTCDateTime
from tiskitpy import (SpectralDensity, ResponseFunctions,
                      CleanRotator, DataCleaner, CleanedStream)

from output_compliance import output_compliance


# read the data and metadata and set the basename for output files
net = 'XX'
sta = 'AS02'
data_dir = '../REAL'
process_base = 'tiskit'
stream = read(f'{data_dir}/{net}.{sta}.mseed')
inv = read_inventory(f'{data_dir}/{net}.{sta}.station.xml')

# Create a superclass of Stream that carries transformation information
stream = CleanedStream(stream)
# Set up a dict in which each value is a different CleanStream
streams = {'original': stream}

#  Reduce Z-channel noise by simple rotation
cr = CleanRotator(stream)
streams['rotated'] = cr.apply(stream)

#  Reduce Z-channel noise by the transfer function removal
#    Tilt and compliance
dc_all = DataCleaner(streams['rotated'], ['*1', '*2', '*H'])
s = dc_all.clean_stream(streams['rotated'])
s.write(f'{net}.{sta}_{process_base}_seismologist.mseed', format='MSEED')
streams['rotated_allCoh'] = s

#    Tilt only
dc_tilt = DataCleaner(streams['rotated'], ['*1', '*2'])
s = dc_tilt.clean_stream(streams['rotated'])
s.write(f'{net}.{sta}_{process_base}_compliancist.mseed', format='MSEED')
streams['rotated_tiltCoh'] = s

#   Calculate and save compliance
wdepth = -inv.select(network=net, station=sta)[0][0].elevation
sd = SpectralDensity.from_stream(streams['rotated_tiltCoh'], inv=inv,)
rf = ResponseFunctions(sd, '*H', ['*Z'])
rf.to_norm_compliance(wdepth)
output_compliance(rf, f'{net}.{sta}_{process_base}', max_freq=0.05)

## UNCOMMENT THE FOLLOWING TO PLOT OUT STUFF

# Input waveforms
# streams['original'].plot()

# Seismologist-cleaned Z-channel
# streams['rotated_allCoh'].plot()

# Comparison of Z PSDs for different cleaning levels
# z_compare = (streams['original'].select(channel='*Z')
#              + streams['rotated'].select(channel='*Z')
#              + streams['rotated_tiltCoh'].select(channel='*Z')
#              + streams['rotated_allCoh'].select(channel='*Z'))
# sd_compare = SpectralDensity.from_stream(z_compare, inv=inv)
# sd_compare.plot(overlay=True)

# P-Z Coherence of compliance-cleaned data
# sd.plot_one_coherence('*Z', '*H')

# P-Z receiver function in normalized compliance units
# rf.plot()
