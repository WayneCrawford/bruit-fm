"""
Takes ResponseFunction, extracts frequency and values, and plots and
saves in standard formats
"""
import warnings

import matplotlib.pyplot as plt
import numpy as np


def output_compliance(rf, name, max_freq=0.05, plotit=False):
    assert len(rf.output_channel_ids) == 1
    id = rf.output_channel_ids[0]
    print('')
    f_all = rf.freqs
    freqs = rf.freqs[f_all <= max_freq]
    compl = rf.value(id)[f_all <= max_freq]
    uncert = rf.uncertainty(id)[f_all < max_freq]
    units = rf.output_units(id) + '/' + rf.input_units
    
    # Select only values for which compl is not None
    freqs = freqs[np.abs(compl) != 0]
    uncert = uncert[np.abs(compl) != 0]
    compl = compl[np.abs(compl) != 0]
    if len(freqs) == 0:
        warnings.warn('No valid compliance values, quitting...')
        return

    with open(f'{name}_compliance_Pa-1.csv', 'w') as fid:
        fid.write('frequency;value;uncertainty;phase\n')
        for f, c, u in zip(freqs.tolist(), compl.tolist(),
                           uncert.tolist()):
            fid.write(f"{f:.3f};{np.abs(c):.4g};{np.abs(u):.4g};{np.angle(u, deg=True):.4g}\n")

    if plotit:
        fig, ax = plt.subplots()
        ax.errorbar(freqs, np.abs(compl)/1.e9, np.abs(uncert)/1.e9,
                    fmt='b_', ecolor='k', markersize=3)
        if np.any(rf is not None):
                ax.set_yscale('log')
        ax.set_xscale('log')
        ax.set_xlabel('Frequency (Hz)')
        ax.set_ylabel(f'Normalized Compliance ({units})')
        ax.set_title(name)
        plt.tight_layout()
        plt.savefig(f'{name}_compliance_Pa-1.png')
        plt.show()
    
