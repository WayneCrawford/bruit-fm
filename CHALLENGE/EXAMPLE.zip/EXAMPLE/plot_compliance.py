"""
Download earthquake-filled data from quiet continental site TAM
"""
import csv

from matplotlib import pyplot as plt

filename = 'tiskit-avoid_compliance_Pa-1.csv'
freqs, ncompls, uncerts, phases = [], [], [], []
with open(filename, newline='') as csvfile:
    reader = csv.DictReader(csvfile, delimiter=';')
    for row in reader:
        freqs.append(float(row['frequency']))
        ncompls.append(float(row['value']))
        uncerts.append(float(row['uncertainty']))
        phases.append(float(row['phase']))

fig, ax = plt.subplots()
ax.errorbar(freqs, ncompls/1.e9, yerr=uncerts/1.e9, capsize=5, ls='None')
ax.set_ylabel('Norm Compliance (1/GPa)')
ax.set_xlabel('Frequency (Hz)')
plt.yscale("log")
plt.tight_layout()
plt.savefig('plot_compliance.png', dpi=300, )
plt.show()