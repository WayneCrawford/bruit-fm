Files:

- XX.AS02.mseed: 8 days of seafloor data
- XX.AS02.station.xml: metadata
- read_and_plot.py: example code for reading and plotting the data.
  Requires obspy ()