Files:

- XX.SYNV1.mseed: 10 days of synthetic seafloor data
- XX.SYNV1.station.xml: metadata
- read_and_plot.py: example code for reading and plotting the data.
  Requires obspy ()