from obspy import read, read_inventory
from obspy.signal import PPSD


# read the data and metadata
stream = read('XX.SYNV1.mseed')
inv = read_inventory('XX.SYNV1.station.xml')

name = 'original'   # start of output filenames

# Plot waveforms and print info
print(stream)
stream.plot(equal_scale=False)

# Plot Z-channel PPSD
ppsd = PPSD(stream.select(channel='LHZ')[0].stats, inv)
ppsd.add(stream)
ppsd.plot(period_lim=(1, 600))
